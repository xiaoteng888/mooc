<template>
    <div>
        <!-- 右侧菜单 -->
        <!-- 底部信息 -->
        <div class="footer" style="margin-bottom: 20px;">
            <div class="copy-box clearfix">
                <!-- 版权 -->
                <p class="copyright">
                    Copyright © 2019 singwa All Rights Reserved | 鄂ICP备17019114号-2
                </p>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "footer"
    }
</script>

<style scoped>

</style>
