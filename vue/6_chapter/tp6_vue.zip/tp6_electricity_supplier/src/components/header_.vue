<template>
    <div class="tab-header">
        <div class="inner">
            <div class="pull-left">
                <div class="pull-left">嗨，欢迎来到<span class="cr" onclick="location.href='/'">singwa商城</span></div>
            </div>
            <div class="pull-right">
                <router-link to="/login"><span class="cr">登录</span></router-link>
                <!--                <router-link to="/reg">注册</router-link>-->
                <router-link to="/mine/center">个人中心</router-link>
                <router-link to="/mine/order">我的订单</router-link>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "header_"
    }
</script>

<style scoped>

</style>
